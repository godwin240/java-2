# Java Servlet - Project : Output
![alt text](output1.png)
![alt text](output2.png)